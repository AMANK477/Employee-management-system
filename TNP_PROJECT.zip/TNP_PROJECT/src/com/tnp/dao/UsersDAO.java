/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tnp.dao;

import com.tnp.bean.UsersBean;
import com.tnp.utility.ConnectionPool;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author babuc
 */
public class UsersDAO {
 static Connection conn;
 public int registerUser(UsersBean ub){
  conn=ConnectionPool.connectDB();
  int r=0;
  String sql = "insert into users(name, email, address, username, password) values('" + ub.getName() + "','" + ub.getEmail() + "','" + ub.getAddress() + "','" + ub.getUsername() + "','" + ub.getPassword() + "')";

     try {
         Statement stmt=conn.createStatement();
        r=stmt.executeUpdate(sql);
     } catch (SQLException ex) {
         Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
     }
  
          return r;
 }
    public int loginCheck(String username,String password) {
        int id=0;
        conn=ConnectionPool.connectDB();
        String sql="select uid from users where username='"+username+"'and password='"+password+"'";
     Statement stmt;
     try {
         stmt = conn.createStatement();
          ResultSet rs=stmt.executeQuery(sql);
     if(rs.next()){
         id=rs.getInt("uid");
     }
     conn.close();
     } catch (SQLException ex) {
         Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
     }
    
     return id;   
    }
    public String forgotPassword(String email){
        String pwd=null;
        conn=ConnectionPool.connectDB();
        String sql="select password from users where email='"+email+"'";
     try {
         Statement stmt=conn.createStatement();
         ResultSet rs=stmt.executeQuery(sql);
         if(rs.next()){
            pwd=rs.getString("password");
         }
     } catch (SQLException ex) {
         Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
     }
        
        return pwd;
    }
    public int changePassword(String email,String oldPassword,String newPassword){
        conn=ConnectionPool.connectDB();
        String select1="select uid from users where password='"+oldPassword+"'";
        int id=0;
     try {
         Statement stmt=conn.createStatement();
         ResultSet rs1=stmt.executeQuery(select1);
         if(rs1.next()){
           String sql="update users set password='"+newPassword+"'where email='"+email+"'"; 
           Statement stmt1=conn.createStatement();
           id=stmt1.executeUpdate(sql);
         }
     } catch (SQLException ex) {
         Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
     }
     return id;
    }
    public static void main(String[] args) {
//        UsersBean ub=new UsersBean();
//        ub.setAddress("Bhopal");
//        ub.setEmail("amankushwahaak47@gmail.com");
//        ub.setMobile("7489861884");
//        ub.setName("Aman Kushwaha");
//        ub.setPassword("1234");
//        ub.setUsername("Aman123");
        
//        UsersDAO ud=new UsersDAO();
//        int x=ud.registerUser(ub);
//        if(x>0){
//            System.out.println("Registration Success");
//        }
//        else{
//            System.out.println("Registration Fail");
//        }
//       UsersDAO ud=new UsersDAO();
//       int a=ud.loginCheck("Aman123","Babu123@");
//       if(a>0){
//           System.out.println("Login Success");
//       }
//       else{
//           System.out.println("Login Fail Please Try again");
//       }
//3. call forgot password 
//UsersDAO ud=new UsersDAO();
//String ps=ud.forgotPassword("amankushwahaak47@gmail.com");
//        System.out.println("Your password:"+ps);


//4.call changePasswor method
UsersDAO ud=new UsersDAO();
int x=ud.changePassword("amankushwahaak47@gmail.com","Babu123@","ABCDE");
        System.out.println(""+x);
    }
}
