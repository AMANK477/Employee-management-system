package com.tnp.dao;

import com.tnp.bean.EmpBean;
import com.tnp.utility.ConnectionPool;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmpDAO {
    static Connection conn;
//1.for Add new employee 
    public int saveEmployee(EmpBean eb) {
        conn = ConnectionPool.connectDB();
        int r = 0;
        String sql = "INSERT INTO emp(name, sal, deptno, gender, comm) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, eb.getName());
            pstmt.setDouble(2, eb.getSal());
            pstmt.setInt(3, eb.getDeptno());
            pstmt.setString(4, eb.getGender());
            pstmt.setDouble(5, eb.getComm());

            r = pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return r;
    }
//    2.for update employee
    public int updateEmployee(EmpBean eb){
        conn=ConnectionPool.connectDB();
        int r=0;
        String sql="update emp set name='"+eb.getName()+"',sal='"+eb.getSal()+"',deptno='"+eb.getDeptno()+"',gender='"+eb.getGender()+"',comm='"+eb.getComm()+"'where empno='"+eb.getEmpno()+"'";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;
    }
//    3.for delete the employee
    public int deleteEmployee(int empno){
      int r=0; 
      conn=ConnectionPool.connectDB();
      String sql="delete from emp where empno='"+empno+"'";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
      return r;
    }
//    4.findALL employee
    public ArrayList<EmpBean>findALL(){
       conn=ConnectionPool.connectDB();
       ArrayList<EmpBean>al=new ArrayList<EmpBean>();
       String sql="select * from emp";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              EmpBean e=new EmpBean();
              e.setEmpno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return al;
    }
    
    
       public ArrayList<EmpBean>findByGender(String gender){
       conn=ConnectionPool.connectDB();
       ArrayList<EmpBean>al=new ArrayList<EmpBean>();
       String sql="select * from emp where gender='"+gender+"'";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              EmpBean e=new EmpBean();
              e.setEmpno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return al;
    }
       public float getTotalSalary(){
           conn=ConnectionPool.connectDB();
           float s=0;
           String sql="select sum(sal) as tsal from emp";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()){
                s=rs.getFloat("tsal");
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
       }
       
       
        public float getAverageSalary(){
           conn=ConnectionPool.connectDB();
           float s=0;
           String sql="select avg(sal) as tsal from emp";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()){
                s=rs.getFloat("tsal");
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
       }
        
         public ArrayList<EmpBean>findAllByDeptNo(int deptno){
       conn=ConnectionPool.connectDB();
       ArrayList<EmpBean>al=new ArrayList<EmpBean>();
       String sql="select * from emp where deptno='"+deptno+"'";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              EmpBean e=new EmpBean();
              e.setEmpno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return al;
    }
         
                 public ArrayList<EmpBean>getHighestSalariedEmployee(){
       conn=ConnectionPool.connectDB();
       ArrayList<EmpBean>al=new ArrayList<EmpBean>();
       String sql="select * from emp where sal=(select max(sal) from emp)";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              EmpBean e=new EmpBean();
              e.setEmpno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return al;
    }
                 
                           public ArrayList<EmpBean>getLowestSalariedEmployee(){
       conn=ConnectionPool.connectDB();
       ArrayList<EmpBean>al=new ArrayList<EmpBean>();
       String sql="select * from emp where sal=(select min(sal) from emp)";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              EmpBean e=new EmpBean();
              e.setEmpno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EmpDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return al;
    }
        
        
    public static void main(String[] args) {
//        EmpBean eb = new EmpBean();
//        eb.setSal(60000);
//        eb.setName("Poornima");
//        eb.setComm(99);
//        eb.setDeptno(100);
//        eb.setGender("Female");
//        EmpDAO ed = new EmpDAO();
//        int x = ed.saveEmployee(eb);
//        if (x > 0) {
//            System.out.println("Employee Added Success");
//        } else {
//            System.out.println("Employee not added");
//        }
//2.Update Employee
//     EmpBean eb=new EmpBean();
//     eb.setComm(91);
//     eb.setDeptno(10);
//     eb.setEmpno(5);
//     eb.setGender("Male");
//     eb.setName("Harsh");
//     eb.setSal(75000);
//     EmpDAO ed=new EmpDAO();
//     int x=ed.updateEmployee(eb);
//     if(x>0){
//         System.out.println("Data update success");
//     }
//     else{
//         System.out.println("Data update fail");
//     }

//3.Call deleteEmployee() method
//EmpDAO dao=new EmpDAO();
//int x=dao.deleteEmployee(4);
//if(x>0){
//    System.out.println("Data delete success");
//}
//else{
//    System.out.println("data not deleted");
//}
//4.find all method
//      EmpDAO dao=new EmpDAO();
//      ArrayList<EmpBean>al=dao.findByGender("female");
//         System.out.println ("Data of All Female Candidate");
//      for(EmpBean x:al){
//          System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getComm()+"\t"+x.getEmpno());
//      }
//6.call total salary
//     EmpDAO ed=new EmpDAO();
//     float sal=ed.getTotalSalary();
//        System.out.println("Total Salary of All Employee:"+sal);
//    
//    }
//}
//    7.call average salary
//     EmpDAO ed=new EmpDAO();
//     float sal=ed.getAverageSalary();
//        System.out.println("Average Salary of All Employee:"+sal);
//    
//    }
//8. Call FindAllByDeptNO
//       EmpDAO dao=new EmpDAO();
//        ArrayList<EmpBean>al=dao.findAllByDeptNo(10);
//         System.out.println ("Data of All Female Candidate");
//      for(EmpBean x:al){
//          System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getComm()+"\t"+x.getEmpno());
//      }
//9.find highest salaried employee
//   EmpDAO dao=new EmpDAO();
//        ArrayList<EmpBean>al=dao.getHighestSalariedEmployee();
//         System.out.println ("Data of All Female Candidate");
//      for(EmpBean x:al){
//          System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getComm()+"\t"+x.getEmpno());
//      } 



//10.find Lowest salaried employee
   EmpDAO dao=new EmpDAO();
        ArrayList<EmpBean>al=dao.findALL();
       
      for(EmpBean x:al){
          System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getComm()+"\t"+x.getEmpno());
      } 
    }
}